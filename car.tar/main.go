package main

import (
	"remotecar/bootstrap"
)

func main() {
	bootstrap.Run()
}
